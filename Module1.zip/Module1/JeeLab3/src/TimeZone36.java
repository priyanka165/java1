import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class TimeZone36 {

	public static void main(String[] args) 
	{
		String[] zone={"America/New_York","Europe/London","Asia/Tokyo",
				"US/Pacific","Africa/Cairo", "Australia/Sydney"};
		for(String temp:zone)
		{
			ZoneId zone1 = ZoneId.of(temp);
			LocalDateTime now1 = LocalDateTime.now(zone1);
			System.out.println(temp+": "
					+now1.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm:ss.ms")));	
		}

	}
}
/*	ZoneId zone1 = ZoneId.of("America/New_York");
ZoneId zone2 = ZoneId.of("Europe/London");

LocalDateTime now1 = LocalDateTime.now(zone1);
LocalDateTime now2 = LocalDateTime.now(zone2);

System.out.println("America/New_York: "
		+now1.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm:ss.ms")));
System.out.println("Europe/London: "
		+now2.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm:ss.ms")));*/
