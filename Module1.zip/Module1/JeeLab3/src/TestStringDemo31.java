import java.util.Scanner;

public class TestStringDemo31 {

	public static void main(String[] args) {
		String s = "";
		int count = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str = sc.next();
		System.out.println("Enter the operation you wish to perform: "
				+ "\n1.Add the String to itself"
				+ "\n2.Replace odd positions with #"
				+ "\n3.Remove duplicate characters in the String"
				+ "\n4.Change odd characters to upper case");
		int choice = sc.nextInt();
		switch (choice) {
		case 1:
			s = str.concat(str);
			break;
		case 2:
			for (int i = 0; i < str.length(); i++) {
				if (i % 2 == 0) {
					s = s + "#";
				}
				else
					s = s + str.charAt(i);
			}
			break;
		case 3:
			for (int i = 0; i < str.length(); i++) {
				for (int j = 0; j < s.length(); j++) {
					if (str.charAt(i) == s.charAt(j))
						count++;
				}
				if (count < 1)
					s = s + str.charAt(i);
				count = 0;
			}
			break;
		case 4:
			for (int i = 0; i < str.length(); i++) {
				if (i % 2 == 0) {
					char c=str.charAt(i);
					s = s + Character.toUpperCase(c);
				}
				else
					s = s + str.charAt(i);
			}
			break;
		default:
			break;
		}
		System.out.println("The altered string is:   " + s);
	}

}
