
public class TestDateDemo {

	public static void main(String[] args) 
	{
		Date priyankaDOJ=new Date(25, 10, 2017);
		System.out.println("My DOJ is: "+priyankaDOJ.dispDate());
		
		Date ruthDOJ=new Date(25, 10, 17);
		System.out.println("My DOJ is: "+ruthDOJ.dispDate());
	}

}
