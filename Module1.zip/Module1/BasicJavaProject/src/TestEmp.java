
public class TestEmp {

	public static void main(String[] args) 
	{
		Employee emp1=new Employee(123,"Priyanka",50000.0F,'F');
		System.out.println("Employee details are:/n1: "+emp1.dispDetails());	
		
		Employee emp2=new Employee(456,"Ruth",1200.0F,'F');
		System.out.println("2: "+emp2.dispDetails());	

	}

}
