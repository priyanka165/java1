
public class Employee 
{
	int empId;
	String empName;
	float empSal;
	char gender;
	
	public Employee()
	{
		empId=0;
		empName="";
		empSal=0;
		gender=' ';
	}
	
	public Employee(int empId,String empName,float empSal,char gender)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
		this.gender=gender;
	}
	public String dispDetails()
	{
		return "Emp ID: "+empId+"\nEmp Name: "+empName+"\nEmp Salary: "+empSal+"\nGender: "+gender;
	}
	
}
