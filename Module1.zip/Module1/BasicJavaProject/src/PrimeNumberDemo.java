
class Prime
{
	int num;
	int prime;
	public int checkPrime(int number)
	{
		prime=0;
		num=number;
		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				prime=0;
				break;
			}
			else
			{
				prime=1;
			}
		}
		return prime;
	}
}
	

public class PrimeNumberDemo 
{

	public static void main(String[] args)
	{
		int prime1=0;
		int number=Integer.parseInt(args[0]);
		Prime obj1=new Prime();
		prime1=obj1.checkPrime(number);
		if(prime1==1)
			System.out.println(number+" is a prime number");
		else
			System.out.println(number+" is not a prime number");

	}

}
