
public class TestEmpArrayDemo 
{

	public static void main(String[] args) 
	{
		Emp emps[]=new Emp[3];
		
		emps[0]=new Emp(111,"Smita",10000.0F);
		emps[1]=new Emp(222,"Dhruvi",20000.0F);
		emps[2]=new Emp(333,"Sameer",30000.0F);

		for(int i=0;i<emps.length;i++)
		{
			System.out.println(i + "th Emp Info:"+emps[i].dispEmpInfo());
			System.out.println("Annual Salary: "+emps[i].calcEmpAnnualSal());
		}
		
		Emp.getCount();
	}

}
