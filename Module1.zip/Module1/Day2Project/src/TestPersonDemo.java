//import java.util.Scanner;

public class TestPersonDemo {

	public static void main(String[] args) 
	{
		Date vDOB=new Date(12,01,1990);
		Date aDOB=new Date(10,8,1974);
		Date pDOB=new Date(17,03,1996);
		
		Person veena=new Person("CBF5645","Veena K",40000.0F,vDOB);
		Person abhi=new Person("TG5645D","Abhishek S",20000.0F,aDOB);

		System.out.println(veena);
		System.out.println(abhi);
		
		//String ge=new Scanner(System.in).next();
		//Gender gen=Gender.valueOf(ge);
		//Person pranita=new Person("CGFE566GH","Pranita",10000.0F,gen,pDOB);
		
		Person pranita=new Person("CGFE566GH","Pranita",10000.0F,Gender.F,pDOB);
		
		System.out.println(pranita);
		
	}

}
