
public class WageEmp extends Emp
{
	int noOfHrs;
	int ratePerHrs;
	public WageEmp()
	{
		super();
	}
	public WageEmp(int empId, String empName, float empSal, int noOfHrs, 
			int ratePerHrs) 
	{
		super(empId, empName, empSal);
		this.noOfHrs = noOfHrs;
		this.ratePerHrs = ratePerHrs;
	
	}
	public String dispEmpInfo()
	{
		return (super.dispEmpInfo())+" Wage Emp:[No of hours:"+noOfHrs+", Rate per Hour:"+ratePerHrs+"]";
	}
	public float calcEmpAnnualSal()
	{
		return (super.calcEmpAnnualSal())+(noOfHrs*ratePerHrs*22*12);
	}
}
