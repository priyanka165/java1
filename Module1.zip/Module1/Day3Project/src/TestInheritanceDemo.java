
public class TestInheritanceDemo 
{

	public static void main(String[] args) 
	{
		Emp priyanka=new Emp(111,"Priyanka D",100000.0F);
		WageEmp sameer=new WageEmp(222,"Sameer Kanase",5000.0F,5,400);
		System.out.println(priyanka.dispEmpInfo());
		System.out.println(sameer.dispEmpInfo());
		System.out.println("Annual Salary Of Priyanka:"
				+priyanka.calcEmpAnnualSal());
		System.out.println("Annual Salary Of Sameer:"
					+sameer.calcEmpAnnualSal());
		
		Emp ruth=new WageEmp(333,"Ruth S M",6000,6,400);
		System.out.println(ruth.dispEmpInfo());
		System.out.println("Annual Salary Of Ruth:"
				+ruth.calcEmpAnnualSal());//Dynamic Binding
		WageEmp priya=new SalesManager(444,"Priya S",4000,5,300,50000,0.02F);
		System.out.println(priya.dispEmpInfo());
		System.out.println("Annual Salary Of Priya:"
				+priya.calcEmpAnnualSal());
		
	}

}
