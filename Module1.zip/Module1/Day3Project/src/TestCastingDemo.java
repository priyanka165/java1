
public class TestCastingDemo 
{
	public static void main(String[] args) 
	{
		Emp e1=null;
		e1=new Emp(111,"Priyanka",1000.0F);
		WageEmp e2=new WageEmp(222,"Sameer",2000.0F,4,500);
		SalesManager e3=new SalesManager(333,"Tripti",3000.0F,5,300,300000,0.02F);
		Emp e4=new WageEmp(444,"Abhi",4000.0F,2,200);
		Emp e5=new SalesManager(666,"Tejaswini",5000.0F,1,300,500000,0.05F);
		e2=(WageEmp)e4;//Explicit type casting
		System.out.println(e2.calcEmpAnnualSal());
		e2=(WageEmp)e1;//Explicit down-casting isn't possible
		System.out.println(e2.calcEmpAnnualSal());
		if(e1 instanceof Emp)
		{
			System.out.println("Yes e1 is an Emp");
		}
		else
		{
			System.out.println("Yes e1 is not an Emp");
		}
		if(e1 instanceof SalesManager)
		{
			System.out.println("Yes e1 is a Sales Manager");
		}
		else
		{
			System.out.println("Yes e1 is not a Sales Manager");
		}
	}
}
