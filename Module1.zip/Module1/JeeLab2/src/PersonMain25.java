import java.util.Scanner;


public class PersonMain25 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);	
		System.out.println("Enter Phone No: ");
		long pno =sc.nextLong();
		Person25 per1=new Person25("Priyanka","D",Gender.F,pno);		
		System.out.println(per1);
		sc.close();
	}
}
