
public class Person24 extends Person{
	private long phoneNo; 

	public Person24()
	{
		super();
	}
	public Person24(String firstName, String lastName, char gender, long phoneNo) 
	{
		super(firstName,lastName,gender);
		this.phoneNo = phoneNo;
	}
	public long getPhoneno() {
		return phoneNo;
	}
	public void setPhoneno(long phoneno) {
		this.phoneNo = phoneno;
	}
	@Override
	public String toString() {
		return super.toString()+"Phone No:" + phoneNo + "\n";
	}
	
}
