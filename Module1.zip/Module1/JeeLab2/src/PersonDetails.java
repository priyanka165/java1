

public class PersonDetails 
{
	public static void main(String[] args) 
	{		
		System.out.println("Person Details:\n_______________\nFirst Name:Priyanka\nLast Name:D\n"
				+ "Gender:F\nAge:21\nWeight:47.0");	
	}
}
