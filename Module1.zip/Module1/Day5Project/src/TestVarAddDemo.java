/*class Calc
{
	public void add(int a,int b)
	{
		int sum=0;
		sum=a+b;
		System.out.println("Sum = "+sum);
	}
}
public class TestVarAddDemo {

	public static void main(String[] args) {
		Calc cc=new Calc();
		cc.add(70,90);
	}

}
*/
class Calc
{
	public void add(String name,int ... nums)
	{
		int sum=0;
		for(int temp:nums)
		{
			sum=sum+temp;
		}
		System.out.println(name+" Sum = "+sum);
	}
}
public class TestVarAddDemo {

	public static void main(String[] args) {
		Calc cc=new Calc();
		cc.add("Priyanka",70,90,100,34,89);
	}

}
