import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class TestPatternDemo {

	public static void main(String[] args) {
		String inputStr="Test String";
		String patern="Test String";
		boolean patternMatched=Pattern.matches(patern, inputStr);
		System.out.println(patternMatched);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name:");
		String firstName=sc.next();
		String namePattern="[A-Z][a-z]+";
		
		if(Pattern.matches(namePattern, firstName))
		{
			System.out.println("Hi "+firstName);
		}
		else
		{
			System.out.println("Invalid name. Should have only"
					+ " characters and should start with capital");
			
		}
		
		System.out.println("*************************************");
		String input="Shop,Mop,Hopping,Chopping";
		Pattern pattern=Pattern.compile("hop");
		Matcher matcher=pattern.matcher(input);
		System.out.println("***********"+matcher.matches());
		while(matcher.find())
		{
			System.out.println(matcher.group()+
					": "+matcher.start()+": "+matcher.end());
		}
	}

}
