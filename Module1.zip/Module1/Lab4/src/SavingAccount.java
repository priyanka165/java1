
public class SavingAccount extends AccountClassForTwoAccount {
	final double minBalance=500;
	
	
	
	public SavingAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SavingAccount(long accNum, double balance, String perName) {
		super(accNum, balance, perName);
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public void withdraw(double bal)
	{
		balance=balance-bal;
		
		if(balance>minBalance)
		{
			System.out.println(toString()); 
		}
		else
		{
			System.out.println("Insufficient Balance");
		}
	}
	
	
	
	
	
	
	

}
