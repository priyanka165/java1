import java.util.Scanner;


public class TestAccount {

	public static void main(String[] args) {
		SavingAccount smith= new SavingAccount();
		CurrentAccount kathy= new CurrentAccount();
		smith.setAccNum(123456789);
		smith.setBalance(2000);
		smith.setPerName("Smith");
		
		kathy.setAccNum(987456321);
		kathy.setBalance(3000);
		kathy.setPerName("Kathy");
				
		Scanner sc=new Scanner(System.in);
		
		 	
		System.out.println("Enter the amount to withdraw: ");
		double wamt=sc.nextDouble();
		smith.withdraw(wamt);
		
		System.out.println("Enter the amount to withdraw: ");
		double samt=sc.nextDouble();
		kathy.withdraw(samt);
		
		 
		sc.close();

	}

}
