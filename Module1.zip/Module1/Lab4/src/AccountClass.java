
public class AccountClass extends PersonClass {
	long accNum;
	double balance;
	PersonClass accHolder;
	
	public AccountClass()
	{
		super();
	}
	
	public AccountClass(String perName,float Age,long accNum, double balance, PersonClass accHolder) {
		super(perName,Age);
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	 
	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public PersonClass getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(PersonClass accHolder) {
		this.accHolder = accHolder;
	}
	
	public double getBalance()
	{
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void deposit(double bal)
	{
		balance=bal+balance;
		System.out.println("Balance in your account: "+balance);
	}
	public void withdraw(double bal)
	{
		if(bal>500)
		{
			balance=balance-bal;
			System.out.println("You have withdrawn: "+bal);
			System.out.println("Current balance is: "+balance);
		}
		else
		{
			System.out.println("Insufficient Balance");
		}
	}

	 
	public String toString() {
		return "AccountClass [Account Number=" + (long) Math.floor(Math.random()*9_000_000_000L) + "\nBalance=" + balance
				+ "\nAge= "+age+ "\nAcc Holder=" + perName+ "]";
	}
	
	
	
}
