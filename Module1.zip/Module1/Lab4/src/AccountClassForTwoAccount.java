
public abstract class AccountClassForTwoAccount {
	 
		long accNum;
		double balance;
		String perName;
		
		
		
		public AccountClassForTwoAccount() {
			super();
			// TODO Auto-generated constructor stub
		}


		public AccountClassForTwoAccount(long accNum, double balance,
				String perName) {
			super();
			this.accNum = accNum;
			this.balance = balance;
			this.perName = perName;
		}


		public long getAccNum() {
			return accNum;
		}


		public void setAccNum(long accNum) {
			this.accNum = accNum;
		}


		public double getBalance() {
			return balance;
		}


		public void setBalance(double balance) {
			this.balance = balance;
		}


		public String getPerName() {
			return perName;
		}


		public void setPerName(String perName) {
			this.perName = perName;
		}


		public abstract void withdraw(double bal);

		 
		public String toString() {
			return "AccountClass [Account Number=" + accNum+ "\nBalance=" + balance
					+"\nAcc Holder=" + perName+ "]";
		}
		
	
}
