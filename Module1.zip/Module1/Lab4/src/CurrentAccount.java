public class CurrentAccount extends AccountClassForTwoAccount {
	final double overDraftLimit = 30000;

		
	public CurrentAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CurrentAccount(long accNum, double balance, String perName) {
		super(accNum, balance, perName);
		// TODO Auto-generated constructor stub
	}
	@Override
	
	public void withdraw(double bal)
	{
		if((balance<bal)&&(bal-balance)<overDraftLimit)
		{
			System.out.println(toString());
		}
		else
		{
			System.out.println("Overdraft Limit Reached");
			System.out.println("Balance in account is : "+balance);
		}
	}
	
	
}
