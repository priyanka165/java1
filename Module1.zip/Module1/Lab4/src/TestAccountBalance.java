import java.util.Scanner;


public class TestAccountBalance {

	public static void main(String[] args) {
		AccountClass smith= new AccountClass();
		AccountClass kathy= new AccountClass();
		smith.setPerName("Smith");
		kathy.setPerName("Kathy"); 
		
		smith.setAge(21.0f);
		kathy.setAge(22.0f);
		
		Scanner sc=new Scanner(System.in);
		
		smith.setBalance(2000.0);
		kathy.setBalance(3000.0);
		System.out.println("Enter the amount to deposit: ");
		double damt= sc.nextDouble();
		smith.deposit(damt);
		System.out.println(smith);
		
		
		System.out.println("Enter the amount to withdraw: ");
		double wamt=sc.nextDouble();
		kathy.withdraw(wamt);
		System.out.println(kathy);
		
	}

}
