
public class PersonClass {
	String perName;
	float age;
	
	public PersonClass()
	{
		
	}
	
	
	public PersonClass(String perName, float age) {
		super();
		this.perName = perName;
		this.age = age;
	}


	public String getPerName() {
		return perName;
	}
	public void setPerName(String perName) {
		this.perName = perName;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
 
	 


	
	
}
