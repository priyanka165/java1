import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class TestDateDemo 
{
	public static void main(String[] args) 
	{
		LocalDate today=LocalDate.now();
		System.out.println("Today is: "+today);

	//	LocalDateTime today1=LocalDateTime.now();
	//	System.out.println("Today is: "+today1);
		System.out.println("Today is in dd-mmm-yyyy"+today.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")));
		
		System.out.println("My date of joining");
		LocalDate myDoj=LocalDate.of(2017, 10, 25);
		System.out.println("My date of joining"+myDoj);
		System.out.println("Date after 2 days:"+today.plusDays(2));
		Period per=Period.between(myDoj, today);
		System.out.println("My date of joining "+per.getYears()+" Years "+per.getMonths()+
				" Months "+per.getDays()+" Days ");
		
		/*LocalDate date=LocalDate.now();
		String text=date.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));
		LocalDate.parsedDate=LocalDate.parse(text,"dd-MMM-yyyy");*/
		
		String myDOBS="16-Dec-1995";
		DateTimeFormatter myFormater=DateTimeFormatter.ofPattern("dd-MMM-uuuu");
		LocalDate myDOB=LocalDate.parse(myDOBS,myFormater);
		System.out.println("My date of birth "+myDOB.format(myFormater));

	}
	
}
