
public class TestInterfaceDemo1 
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Printable p1=new Customer(222,"Vaishali");
		p1.print();
		System.out.println(p1.sayHi());
	}

}
