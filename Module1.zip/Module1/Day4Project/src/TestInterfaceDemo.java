
public class TestInterfaceDemo 
{

	public static void main(String[] args) 
	{
		Printable pArr[]=new Printable[2];
		pArr[0]=new Customer(222,"Vaishali");
		pArr[1]=new Customer(111,"Sameer");
		pArr[0].print();
		pArr[1].print();
	}

}
