
public class TestAccount{

	public static void main(String[] args) {
		long accNum=100;
		Person per1= new Person("Smith",30);
		Person per2= new Person("Kathy",31);
		SavingsAccount sa=new SavingsAccount(accNum++,2000,per1);
		CurrentAccount ca=new CurrentAccount(accNum++,3000,per2);
		sa.withdraw(1600);
		ca.withdraw(7000);
		System.out.println(sa);
		System.out.println(ca);
	}

}
