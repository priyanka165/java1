
public class TestPersonAccount {

	public static void main(String[] args) {
		long accNum=100;
		Person per1= new Person("Smith",30);
		Person per2= new Person("Kathy",31);
		Account acc1 = new Account(accNum++,2000,per1);
		Account acc2 = new Account(accNum++,3000,per2);
		acc1.deposit(2000);
		acc2.withdraw(2000);
		System.out.println(acc1);
		System.out.println(acc2);
	}

}
