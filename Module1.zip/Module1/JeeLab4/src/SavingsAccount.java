
public class SavingsAccount extends Account{

	final double minimumBalance=500;

	public SavingsAccount() {
		super();
	}

	public SavingsAccount(long accNum, double balance, Person accHolder) {
		super(accNum, balance, accHolder);
	}

	public double getMinimumBalance() {
		return minimumBalance;
	}

	@Override
	public void withdraw(double wd) {
		double bal=balance-wd;	
		if(bal>minimumBalance)
		{
			balance=bal;
			//System.out.println(toString());
		}
		else
			System.out.println("Insufficient balance. Cannot Withdraw.");
	}

}
