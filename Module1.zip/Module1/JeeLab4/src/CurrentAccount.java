
public class CurrentAccount extends Account{

	double overdraftLimit=3000;

	public CurrentAccount() {
		super();
	}

	public CurrentAccount(long accNum, double balance, Person accHolder) {
		super(accNum, balance, accHolder);
	}

	public double getOverdraftLimit() {
		return overdraftLimit;
	}

	public void setOverdraftLimit(double overdraftLimit) {
		this.overdraftLimit = overdraftLimit;
	}
	
	@Override
	public void withdraw(double wd) {
		if((balance<wd) && ((wd-balance)<overdraftLimit))
		{
			balance-=wd;
			//System.out.println(toString());
		}
		else if(balance>wd)
		{
			balance-=wd;
			//System.out.println(toString());
		}
		else
			System.out.println("Overdraft limit reached. Cannot Withdraw.");
	}
	
}
