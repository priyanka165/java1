import java.util.Scanner;

public class TestPersonWithArray 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the count of people: ");
		int num=sc.nextInt();

		Person pers1[]= new Person[num];

		for(int i=0;i<num;i++)
		{
			System.out.println("Enter Pan No: ");
			String pno =sc.next();

			System.out.println("Enter Person Name: ");
			String pnm =sc.next();

			System.out.println("Enter Person Sal: ");
			float psl =sc.nextFloat();

			System.out.println("Enter date: ");
			int da =sc.nextInt();

			System.out.println("Enter month: ");
			int mo =sc.nextInt();

			System.out.println("Enter year: ");
			int yr =sc.nextInt();

			Date pers=new Date(da,mo,yr);
			pers1[i]=new Person(pno,pnm,psl,pers);
		}



		for(int i=0;i<num;i++)
		{

			System.out.println("Person details:\n"+pers1[i].dispPersonInfo());
		}

	}

}


