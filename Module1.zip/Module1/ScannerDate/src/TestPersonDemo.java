import java.util.Scanner;

public class TestPersonDemo {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
	
		System.out.println("Enter Pan No: ");
		String pno =sc.next();
		
		System.out.println("Enter Person Name: ");
		String pnm =sc.next();
		
		System.out.println("Enter Person Sal: ");
		float psl =sc.nextFloat();
		
		System.out.println("Enter date: ");
		int da =sc.nextInt();
		
		System.out.println("Enter month: ");
		int mo =sc.nextInt();
		
		System.out.println("Enter year: ");
		int yr =sc.nextInt();	
		
		 Date per=new Date(da,mo,yr);
		 Person per1=new Person(pno,pnm,psl,per);
		

		System.out.println("Person details:"+per1.dispPersonInfo());
		
	}

}
