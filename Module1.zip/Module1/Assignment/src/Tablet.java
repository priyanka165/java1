
public class Tablet extends Medicine
{
	public Tablet() 
	{
	}
	public Tablet(String medName, String compName, String expDate, float price)
	{
		super(medName,compName,expDate,price);
	}
	@Override
	public String toString() {
		return super.toString()+"\nStore in a cool and dry place";
	}
}
