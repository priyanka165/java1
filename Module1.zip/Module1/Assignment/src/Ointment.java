
public class Ointment extends Medicine
{
	public Ointment() 
	{
	}
	public Ointment(String medName, String compName, String expDate, float price)
	{
		super(medName,compName,expDate,price);
	}
	@Override
	public String toString() {
		return super.toString()+"\nFor external use only";
	}
}
