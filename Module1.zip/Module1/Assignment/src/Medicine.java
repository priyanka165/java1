
public class Medicine 
{
	private String medName;
	private String compName;
	private String expDate;
	private float price;
	public Medicine() {}
	public Medicine(String medName, String compName, String expDate, float price) 
	{
		this.medName = medName;
		this.compName = compName;
		this.expDate = expDate;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Medicine [medName=" + medName + ", compName=" + compName
				+ ", expDate=" + expDate + ", price=" + price + "]";
	}
	
}
