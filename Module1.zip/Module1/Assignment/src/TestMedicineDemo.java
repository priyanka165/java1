import java.util.Scanner;

public class TestMedicineDemo 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of meds: ");
		int n=sc.nextInt();
		Medicine meds[]=new Medicine[n];
		for(int i=0;i<meds.length;i++)
		{	
			System.out.println("\nEnter your choice\n1.Tablet\n2.Ointment\n3.Syrup");
			int choice=sc.nextInt();
			System.out.println("Enter Medicine Name: ");
			String medname=sc.next();
			System.out.println("Enter Company Name: ");
			String compname=sc.next();
			System.out.println("Enter Expiry Date: ");
			String exdate=sc.next();
			System.out.println("Enter price: ");
			int price=sc.nextInt();
			switch(choice)
			{
			case 1:
				meds[i]=new Tablet(medname,compname,exdate,price);
				break;
			case 2:
				meds[i]=new Ointment(medname,compname,exdate,price);
				break;
			case 3:
				meds[i]=new Syrup(medname,compname,exdate,price);
				break;
			}
			if(meds[i] instanceof Tablet)
				System.out.println(i+".Tablet Info: "+meds[i]);
			if(meds[i] instanceof Ointment)
				System.out.println(i+".Ointment Info: "+meds[i]);
			if(meds[i] instanceof Syrup)
				System.out.println(i+".Syrup Info: "+meds[i]);
		}
	}

}
