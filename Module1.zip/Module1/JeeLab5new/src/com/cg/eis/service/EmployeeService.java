package com.cg.eis.service;

public interface EmployeeService{
	public String insuranceScheme(float empSal, String empDesg);
	
		
	

}
