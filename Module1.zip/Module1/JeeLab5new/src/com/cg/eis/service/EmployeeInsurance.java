package com.cg.eis.service;
import com.cg.eis.bean.Employee;

public class EmployeeInsurance implements EmployeeService {
	 
	

	@Override
	public String insuranceScheme(float empSal, String empDesg) {
		 String str="";
		 if(empSal>5000 && empSal<20000 && empDesg.equals("SystemAssociate"))
		 {
			System.out.println("Scheme C"); 
		 }
		 else if (empSal>=20000 && empSal<40000 && empDesg.equals("Programmer"))
		 {
			 System.out.println("Scheme B");
		 }
		 else if (empSal>=40000 && empDesg.equals("Manager"))
		 {
			 System.out.println("Scheme A");
		 }
		 else
		 {
			 System.out.println("No Scheme");
		 }
		 return str; 
	}
	
}
