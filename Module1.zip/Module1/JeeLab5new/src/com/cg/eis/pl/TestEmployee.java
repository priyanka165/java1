package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class TestEmployee {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Employee ID: ");
		int empid=sc.nextInt();
		System.out.println("Enter the Employee Name: ");
		String empname=sc.next();
		System.out.println("Enter the Employee Designation: ");
		String empdesgn= sc.next();
		System.out.println("Enter the salary: ");
		float empsal= sc.nextFloat();
		
		Employee emp=new Employee(empid, empname, empdesgn,empsal);
		System.out.println(emp.toString());
		emp.insuranceScheme(empsal, empdesgn);
		

	}

}
