package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDAOImplementation implements EmployeeDAO {

	public int generateEmployeeID() {
		int id = 0;
		Connection con = null;
		String qry = "select employeeid_sequence.nextval from dual";
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id = rst.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con = null;
		String command = "insert into employee_table(emp_id,emp_firstname,"
				+ "emp_lastname,emp_contact,emp_doj,emp_email) values(?,?,?,?,SYSDATE,?)";
		int id = 0;
		PreparedStatement pstmt;
		try {
			con = DBConnection.getConnection();
			id = generateEmployeeID();
			pstmt = con.prepareStatement(command);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmpFirstName());
			pstmt.setString(3, bean.getEmpLastName());
			pstmt.setLong(4, bean.getEmpContact());
			pstmt.setString(5, bean.getEmpEmail());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			throw new EmployeeException("Unable to insert");
		}
		return id;
	}
	
	public String viewById(int id) throws EmployeeException{
		Connection con=null;
		EmployeeBean bean=new EmployeeBean();
		String command="select emp_id,emp_firstname,emp_lastname,emp_contact,emp_doj,emp_email from employee_table where emp_id="+id;
		
		try {
			
			con=DBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(command);
			System.out.println("Employee Details are: ");
			rst.next();
			bean.setEmpId(rst.getInt(1));
			bean.setEmpFirstName(rst.getString(2));
			bean.setEmpLastName(rst.getString(3));
			bean.setEmpContact(rst.getLong(4));
			bean.setEmpDOJ(rst.getDate(5));
			bean.setEmpEmail(rst.getString(6));
				
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return (bean.getEmpId()+" "+bean.getEmpFirstName()+" "+bean.getEmpLastName()+
				" "+bean.getEmpContact()+" "+bean.getEmpDOJ()+" "+bean.getEmpEmail());
	}
	

}
