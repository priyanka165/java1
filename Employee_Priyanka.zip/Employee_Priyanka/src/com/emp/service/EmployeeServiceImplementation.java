package com.emp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDAO;
import com.emp.dao.EmployeeDAOImplementation;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImplementation implements EmployeeService {

	EmployeeDAO employeedao = new EmployeeDAOImplementation();

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id = employeedao.addEmployee(bean);
		return id;
	}

	public String viewById(int id) throws EmployeeException {
		String bean = employeedao.viewById(id);
		return bean;
	}

	public boolean validateEmployee(EmployeeBean bean) throws EmployeeException {
		List<String> validationErrors = new ArrayList<String>();

		// Validating employee first name
		if (!(isValidFirstName(bean.getEmpFirstName()))) {
			validationErrors
			.add("\n Employee First Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		// Validating employee last name
		if (!(isValidLastName(bean.getEmpLastName()))) {
			validationErrors
			.add("\n Employee Last Name Should Be In Alphabets and between 1 to 15 characters long ! \n");
		}
		// Validating employee Contact Number
		if (!(isValidContact(bean.getEmpContact()))) {
			validationErrors
			.add("\n Contact Number Should be 10 digits long and first "
					+ "digit shouldn't be 0 \n");
		}
		// Validating employee email ID
		if (!(isValidEmail(bean.getEmpEmail()))) {
			validationErrors.add("\n Give valid email Id \n");
		}

		if (!validationErrors.isEmpty())
			throw new EmployeeException(validationErrors + "");
		else 
			return true;
	}

	public boolean isValidFirstName(String empFirstName) {
		Pattern fnamePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher fnameMatcher = fnamePattern.matcher(empFirstName);
		return fnameMatcher.matches();
	}

	public boolean isValidLastName(String empLastName) {
		Pattern lnamePattern = Pattern.compile("^[A-Za-z]{1,15}$");
		Matcher lnameMatcher = lnamePattern.matcher(empLastName);
		return lnameMatcher.matches();
	}

	public boolean isValidContact(Long contactNumber) {
		Pattern contactPattern = Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher contactMatcher = contactPattern.matcher(String
				.valueOf(contactNumber));
		return contactMatcher.matches();
	}

	public boolean isValidEmail(String empEmail) {
		Pattern emailPattern = Pattern.compile("[a-z]{1,5}@[a-z]{1,5}.com");
		Matcher emailMatcher = emailPattern.matcher(empEmail);
		return emailMatcher.matches();
	}

}
