package com.emp.service;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDAO;
import com.emp.dao.EmployeeDAOImplementation;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImplementation implements EmployeeService {

	EmployeeDAO employeedao = new EmployeeDAOImplementation();
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id = employeedao.addEmployee(bean);
		return id;
	}
	public String viewById(int id) throws EmployeeException{
		String bean=employeedao.viewById(id);
		return bean;
	}
}
