package com.emp.service;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeService {
	int addEmployee(EmployeeBean bean)throws EmployeeException;
	String viewById(int id) throws EmployeeException;
}
