package com.emp.pl;

import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImplementation;

public class EmployeeAPP {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeBean bean = new EmployeeBean();
		EmployeeService service = new EmployeeServiceImplementation();

		System.out.println("Select operation:\n1.ADD Employee\n2.VIEW Employee by ID"
				+ "\n3.EXIT");
		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			System.out.println("Enter Employee's FirstName: ");
			String fname = sc.next();
			System.out.println("Enter Employee's LastName: ");
			String lname = sc.next();
			System.out.println("Enter Employee's Contact Number: ");
			long contact = sc.nextLong();
			System.out.println("Enter Employee's Email ID");
			String email = sc.next();
			bean.setEmpFirstName(fname);
			bean.setEmpLastName(lname);
			bean.setEmpContact(contact);
			bean.setEmpEmail(email);
			try {
				int id = service.addEmployee(bean);
				System.out.println("Employee Added Successfully");
				System.out.println("Employee ID: " + id);
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
			break;
		case 2:
			try{
				System.out.println("Enter the Employee's ID:");
				int id=sc.nextInt();
				System.out.println(service.viewById(id));
			}catch(EmployeeException e){
				e.printStackTrace();
			}
			break;
		case 3:
			break;
		default:
			break;
		}
		sc.close();
	}

}
