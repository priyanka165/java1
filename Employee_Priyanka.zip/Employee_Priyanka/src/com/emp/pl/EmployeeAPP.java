package com.emp.pl;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImplementation;

public class EmployeeAPP {

	static EmployeeServiceImplementation serviceimpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		EmployeeBean bean = new EmployeeBean();
		EmployeeService service = new EmployeeServiceImplementation();

		System.out
				.println("Select operation:\n1.ADD Employee\n2.VIEW Employee by ID"
						+ "\n3.EXIT");
		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			System.out.println("Enter Employee's FirstName: ");
			String fname = sc.next();
			System.out.println("Enter Employee's LastName: ");
			String lname = sc.next();
			System.out.println("Enter Employee's Contact Number: ");
			long contact = sc.nextLong();
			System.out.println("Enter Employee's Email ID");
			String email = sc.next();

			bean.setEmpFirstName(fname);
			bean.setEmpLastName(lname);
			bean.setEmpContact(contact);
			bean.setEmpEmail(email);
			serviceimpl = new EmployeeServiceImplementation();

			try {
				if(serviceimpl.validateEmployee(bean))
				{
					int id = service.addEmployee(bean);
					System.out.println("Employee Added Successfully");
					System.out.println("Employee ID: " + id);
					logger.info("Validation successful. Employee added with proper ID.");
				}
				else
				{
					System.out.println("Insertion Failed");
				}
			} catch (EmployeeException e1) {
				logger.error("Exception Occured", e1);
				e1.printStackTrace();
			}
			break;
		case 2:
			try {
				System.out.println("Enter the Employee's ID:");
				int id = sc.nextInt();
				System.out.println(service.viewById(id));
			} catch (EmployeeException e) {
				logger.error("Exception Occured", e);
				e.printStackTrace();
			}
			break;
		case 3:
			System.out.println("Application exited");
			logger.info("Application exited");
			System.exit(0);
			break;
		default:
			System.out.println("Enter valid choice(i.e. 1-3)");
			logger.info("Invalid choice of operation");
			break;
		}
		sc.close();
	}

}
