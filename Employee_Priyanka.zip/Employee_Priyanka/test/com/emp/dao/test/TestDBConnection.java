package com.emp.dao.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.Test;

import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class TestDBConnection {

	@Test
	public void testConnection() throws EmployeeException {
		Connection con = DBConnection.getConnection();
		assertNotNull(con);
	}

	@Test(expected = EmployeeException.class)
	public void testConnectionFail() throws EmployeeException {
		Connection con = DBConnection.getConnection();
	}
}
