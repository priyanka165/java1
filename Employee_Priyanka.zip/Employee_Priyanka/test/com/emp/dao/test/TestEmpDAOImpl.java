package com.emp.dao.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDAOImplementation;
import com.emp.exception.EmployeeException;

public class TestEmpDAOImpl {

	static EmployeeDAOImplementation employeeDao;
	static EmployeeBean bean;

	@BeforeClass
	public static void beforeClass() {
		employeeDao = new EmployeeDAOImplementation();
		bean = new EmployeeBean();
	}

	@Test
	public void testAddEmployee() throws EmployeeException {
		bean.setEmpFirstName("Priyanka");
		bean.setEmpLastName("D");
		bean.setEmpContact(8861159107L);
		bean.setEmpEmail("abc@gmail.com");
		int id = employeeDao.addEmployee(bean);
		assertTrue(id > 0);
	}
}
