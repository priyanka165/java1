

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Ignore;
import org.junit.Test;

import com.emp.exception.MobileException;
import com.emp.util.DBConnection;

public class TestConnection 
{
	@Test
	public void testConnection() throws MobileException
	{
		System.out.println("establishing connection..");
		Connection con = DBConnection.getConnection();
		assertNotNull(con);
		System.out.println("connected to database!");
	}
	
	@Ignore
	@Test(expected=MobileException.class)
	public void testConnectionFails() throws MobileException, SQLException
	{
		System.out.println("testing exception for connection..");
		Connection con = DBConnection.getConnection();
		System.out.println("no exception found,thus testConnectionFails failed..");
		con.close();
	}
	
}
