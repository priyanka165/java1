package com.emp.bean;

public class MobileBean 	
{
	private int mobileid;
	private String name;
	private int price;
	private String quantity;
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return    " mobileid  :" + mobileid +"\n"
				+ " name      :" + name +"\n"
				+ " price     :" + price  +"\n"
				+ " quantity  :" + quantity+"\n";
	}
}
