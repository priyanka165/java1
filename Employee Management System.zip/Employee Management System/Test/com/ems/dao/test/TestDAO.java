package com.ems.dao.test;

import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDAOImplement;
import com.emp.exception.EmployeeException;

public class TestDAO {
	
	static EmployeeDAOImplement employeedao;
	static EmployeeBean empBean;
	
	@BeforeClass
	public static void beforeClass()
	{
		employeedao=new EmployeeDAOImplement();
		empBean=new EmployeeBean();
	}
	
	@Test
	public void testAddEmp()throws EmployeeException{
		empBean.setEmpname("Shubh");
		empBean.setEmpsalary(100000);
		int id=employeedao.addEmployee(empBean);
		assertTrue(id>0);
	}

}
