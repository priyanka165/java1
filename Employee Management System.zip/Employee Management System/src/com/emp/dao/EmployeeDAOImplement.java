package com.emp.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDAOImplement implements EmployeeDAO{
	
	Logger log=Logger.getLogger(EmployeeDAOImplement.class);
	
	
	public EmployeeDAOImplement() {
		super();
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	public int generateEmployeeID()
	{
	int id=0;
	Connection con=null;
	String qry="select emp_seq.nextval from dual";
		try {
			con=DBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(qry);
			rst.next();
			id=rst.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con=null;
		//String cmd="insert into emp_tbl(empid,empname,empsalary) values(emp_seq.nextval,?,?)";
		//kyuki mujhe id return karna hai
		String cmd="insert into emp_tbl(empid,empname,empsalary) values(?,?,?)";
		int id=0;
		PreparedStatement pstmt;
		log.debug("Add Employee is called from EmployeeDao");
		log.info("Add Employee Called");

		try {
			con=DBConnection.getConnection();
			id=generateEmployeeID();
			pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmpname());
			pstmt.setInt(3, bean.getEmpsalary());
			pstmt.executeUpdate();
			log.info("Insert Successful");

		} catch (SQLException e) {
			log.debug("Insertion Failed"+e);
		throw new EmployeeException("Unable to insert");
		}
		
		return id;
	}
	@Override
	public void delEmployee(int id) throws EmployeeException{
		Connection con=null;
		String cmd="delete from emp_tbl where empid="+id;
		
			try {
				con=DBConnection.getConnection();
				Statement stmt=con.createStatement();
				stmt.executeUpdate(cmd);
				System.out.println("Row has been deleted");
			} catch (SQLException e) {
				System.out.println("No employee found with such ID ");
			}
	}
			
	public String viewById(int id) throws EmployeeException{
		Connection con=null;
		EmployeeBean bean=new EmployeeBean();
		String cmd="select empid,empname,empsalary from emp_tbl where empid="+id;
		
		try {
			
			con=DBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(cmd);
			System.out.println("Employee Details are: ");
			rst.next();
			bean.setEmpid(rst.getInt(1));
			bean.setEmpname(rst.getString(2));
			bean.setEmpsalary(rst.getInt(3));
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return (bean.getEmpid()+" "+bean.getEmpname()+" "+bean.getEmpsalary());
	}
	
	public List<EmployeeBean> viewAllEmployees(EmployeeBean bean) throws EmployeeException{
		Connection con=null;
		
		List<EmployeeBean> empList=new ArrayList<EmployeeBean>();
		String cmd="select empid,empname,empsalary from emp_tbl";

		try {
			
			con=DBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(cmd);
			System.out.println("Employee Details are: ");
			
			while(rst.next()){
				EmployeeBean bean1=new EmployeeBean();
			bean1.setEmpid(rst.getInt(1));
			bean1.setEmpname(rst.getString(2));
			bean1.setEmpsalary(rst.getInt(3));
			empList.add(bean1);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		return empList;
	
	}
}
	
