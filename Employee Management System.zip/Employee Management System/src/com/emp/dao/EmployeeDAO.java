package com.emp.dao;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeDAO {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public void delEmployee(int id) throws EmployeeException;
	public String viewById(int id) throws EmployeeException;
	public List<EmployeeBean> viewAllEmployees(EmployeeBean bean) throws EmployeeException;
	
}
