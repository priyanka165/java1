package com.emp.pl;

import java.util.List;
import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImplementation;

public class EMSApp {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		
		EmployeeBean bean=new EmployeeBean();
		EmployeeService service=new EmployeeServiceImplementation();
		
		System.out.println("Select your operation: \n1.Add Employee\n2.Delete Employee \n3.View Employee by Id \n4.View all employees \n5.Exit");
		int ch=scan.nextInt();
		switch (ch){
		case 1:
			System.out.println("Enter employee's name");
			String ename=scan.next();
			System.out.println("Enter employee's salary");
			int esal=scan.nextInt();
			bean.setEmpname(ename);
			bean.setEmpsalary(esal);			
			try {
					int id = service.addEmployee(bean);
					System.out.println("Employee Added Successfully");
					System.out.println("Employee ID: "+id);
				} catch (EmployeeException e) {
					e.printStackTrace();
				}
				break;
		case 2:
			try{
				System.out.println("Enter the Employee's ID:");
				int id=scan.nextInt();
				service.delEmployee(id);
			}catch (EmployeeException e){
				e.printStackTrace();
			}
			break;
		
		case 3:
			try{
				System.out.println("Enter the Employee's ID:");
				int id=scan.nextInt();
				System.out.println(service.viewById(id));
			}catch(EmployeeException e){
				e.printStackTrace();
			}
			break;
				
		
		case 4:
			try{
				List<EmployeeBean> list=service.viewAllEmployees(bean);
				for(EmployeeBean bean1:list)
				{
					System.out.println(bean1.getEmpid()+" "+bean1.getEmpname()+" "+bean1.getEmpsalary());
				}
			}catch(EmployeeException e){
				e.printStackTrace();
			}
			break;

		case 5:
			break;
		}		
			scan.close();
		

	
	}
}

