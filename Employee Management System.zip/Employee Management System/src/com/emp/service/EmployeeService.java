package com.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeService {
	int addEmployee(EmployeeBean bean)throws EmployeeException;
	void delEmployee(int id) throws EmployeeException;
	String viewById(int id) throws EmployeeException;
	List<EmployeeBean> viewAllEmployees(EmployeeBean bean) throws EmployeeException;

}
