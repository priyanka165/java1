
public class PersonMain {

	public static void main(String[] args) {
	Person per1=new Person("Priyanka","D",'F');
	Person per2=new Person("Ruth","Das",'F');
	
	System.out.println(per1);
	System.out.println(per2);
	}

}
