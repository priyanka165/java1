enum Gender
{
	M,F;
}
public class Person25 {
	private String firstName;
	private String lastName;
	private long phoneNo;
	Gender gender;

	public Person25()
	{

	}
	public Person25(String firstName, String lastName,Gender gender, long phoneNo) 
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
		this.phoneNo=phoneNo;
	}

	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "\nPerson details:\n______________\nFirst Name:" + firstName + "\nLast Name:" + lastName
				+ "\nGender:"+gender+"\nPhone No:"+phoneNo;
	}
}
