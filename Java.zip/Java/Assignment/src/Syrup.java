
public class Syrup extends Medicine
{
	public Syrup() 
	{
	}
	public Syrup(String medName, String compName, String expDate, float price)
	{
		super(medName,compName,expDate,price);
	}
	@Override
	public String toString() {
		return super.toString()+"\nShake well before use";
	}
}
