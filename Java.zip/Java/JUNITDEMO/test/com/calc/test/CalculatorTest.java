package com.calc.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.calc.Calculator;

public class CalculatorTest {
	static Calculator obj;

	@BeforeClass
	public static void beforeTest() {
		obj = new Calculator();
	}

	@Test
	public void testAdd() {
		int n = obj.add(10, 20);
		assertEquals(30, n);
	}

	@Test
	public void testSub() {
		int n = obj.sub(10, 5);
		assertEquals("Testing 10 and 5", 5, n);
	}

	@Test
	public void testDivide() {
		int n = obj.divide(10, 5);
		assertEquals(2, n);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testDivideException() {
		int n = obj.divide(20, 0);
	}
}
