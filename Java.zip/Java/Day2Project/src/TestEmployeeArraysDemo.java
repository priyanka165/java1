import java.util.Scanner;

public class TestEmployeeArraysDemo {
	
	private static String city="Bangalore";
	public void method1(){}
	public static void main(String[] args) 
	{
		System.out.println("Main starts here-------");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size n: ");
		int n=sc.nextInt();
		
		Emp emps[]=new Emp[n];
		for(int i=0;i<emps.length;i++)
		{
			System.out.println("Enter Emp Id: ");
			int eid=sc.nextInt();
			
			System.out.println("Enter Emp Name: ");
			String enm=sc.next();
			
			System.out.println("Enter Emp Salary: ");
			float esl=sc.nextFloat();
			emps[i]=new Emp(eid,enm,esl);
		}		
		for(int i=0;i<emps.length;i++)
		{
			System.out.println("\n Emp Info: "+emps[i].dispEmpInfo());
			System.out.println("Emp Annual Salary: "+emps[i].calcEmpAnnualSal());
		}
		
		Emp.getCount();

	}

}
