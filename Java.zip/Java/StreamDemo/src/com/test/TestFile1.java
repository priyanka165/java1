package com.test;

import java.io.File;

public class TestFile1 {

	public static void main(String[] args) {

		/*
		 * String str = "sample.txt"; File file = new File(str); if
		 * (file.exists()) { System.out.println("Length = " + file.length()); }
		 * else System.out.println("FILE NOT FOUND"); }
		 */

		String str = "c:/Windows";
		File file = new File(str);
		if (file.exists() && file.isDirectory()) {
			String[] listOfFiles = file.list();
			for (String fileName : listOfFiles) {
				System.out.println(fileName);
			}
		} else
			System.out.println("NOT A DIRECTORY");
	}

}
