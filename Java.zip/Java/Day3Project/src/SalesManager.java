
public class SalesManager extends WageEmp
{
	int sale;
	float commission;

	public SalesManager()
	{
		super();
	}

	public SalesManager(int empId, String empName, float empSal, int noOfHrs,
			int ratePerHrs, int sale, float commission) {
		super(empId, empName, empSal, noOfHrs, ratePerHrs);
		this.sale = sale;
		this.commission = commission;
	}
	public String dispEmpInfo()
	{
		return (super.dispEmpInfo())+" Sales Manager:[Sale in Rs:"+sale+", Commission:"+commission+"]";
	}
	
	public float calcEmpAnnualSal()
	{
		return (super.calcEmpAnnualSal())+(sale*commission);
	}
}