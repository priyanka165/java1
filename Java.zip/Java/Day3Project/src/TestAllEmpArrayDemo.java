
public class TestAllEmpArrayDemo {

	public static void main(String[] args) 
	{
		Emp emps[]=new Emp[6];
		emps[0]=new Emp(111,"Priyanka",1000.0F);
		emps[1]=new WageEmp(222,"Sameer",2000.0F,3,300);
		emps[2]=new SalesManager(333,"Abhishek",3000.0F,3,300,600000,0.06F);
		emps[3]=new Emp(444,"Tejaswini",78000.0F);
		emps[4]=new WageEmp(555,"Tripti",45000.0F,4,400);
		emps[5]=new SalesManager(666,"Ramesh",34000.0F,2,400,400000,0.04F);

		for(int i=0;i<emps.length;i++)
		{
			if(emps[i] instanceof SalesManager)
			{
				System.out.println(i+"th Sales Manager Info:"
						+emps[i].dispEmpInfo());
				System.out.println("Annual Salary:"
						+emps[i].calcEmpAnnualSal());
			}
			else if(emps[i] instanceof WageEmp)
			{
				System.out.println(i+"th Wage Emp:"
						+emps[i].dispEmpInfo());
				System.out.println("Annual Salary:"
						+emps[i].calcEmpAnnualSal());
			}
			else
			{
				System.out.println(i+"th Emp Info:"
						+emps[i].dispEmpInfo());
				System.out.println("Annual Salary:"
						+emps[i].calcEmpAnnualSal());
			}
		}
	}
}
