import java.util.Scanner;

public class TestAllEmpArrayDemo2 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size n: ");
		int n=sc.nextInt();
		Emp emps[]=new Emp[n];
		for(int i=0;i<emps.length;i++)
		{
			System.out.println("Enter Emp Id: ");
			int empid=sc.nextInt();
			System.out.println("Enter Emp name: ");
			String empname=sc.next();
			System.out.println("Enter Emp Sal: ");
			float empsal=sc.nextFloat();
			System.out.println("Enter type of emp:1.Wage Emp\n"
					+ "2.Sales Manager\n ");
			int emptype=sc.nextInt();
			switch(emptype)
			{
			case 1:
				System.out.println("Enter No. of hours: ");
				int noofhrs=sc.nextInt();
				System.out.println("Enter Rate per hour: ");
				int rate=sc.nextInt();
				emps[i]=new WageEmp(empid,empname,empsal,noofhrs,rate);
				break;
			case 2:
				System.out.println("Enter No. of hours: ");
				noofhrs=sc.nextInt();
				System.out.println("Enter Rate per hour: ");
				rate=sc.nextInt();
				System.out.println("Enter Emp sales: ");
				int empsale=sc.nextInt();
				System.out.println("Enter Emp commission: ");
				float comm=sc.nextFloat();
				emps[i]=new SalesManager(empid,empname,empsal,noofhrs,rate,empsale,comm);
				break;
			default:
				emps[i]=new Emp(empid,empname,empsal);
				break;
			}
		}

		for(int i=0;i<emps.length;i++)
		{

			System.out.println(i+"th Emp Info:"
					+emps[i].dispEmpInfo());
			System.out.println("Annual Salary:"
					+emps[i].calcEmpAnnualSal());

		}
	}
}
