package com.test;

public class TestThread {

	public static void main(String[] args) throws Exception {

		FirstThread first = new FirstThread();
		SecondThread second = new SecondThread();

		/*
		 * first.start(); second.start(); first.join(); second.join();
		 */

		Thread t1 = new Thread(first);
		Thread t2 = new Thread(second);
		t1.start();
		t2.start();
		System.out.println(t1.currentThread());
		System.out.println("MAIN COMPLETED" + Thread.currentThread());
	}

}
