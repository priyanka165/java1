package com.test;

import java.util.ArrayList;

public class TestCollection {

	public static void main(String[] args) {
		
		ArrayList list=new ArrayList();
		list.add("orange");
		list.add("apple");
		list.add("banana");
		int n=list.size();
		System.out.println("size="+n);
	}

}
