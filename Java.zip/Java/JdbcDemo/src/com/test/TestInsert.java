package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestInsert {

	public static void main(String[] args) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver register success");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "SYSTEM";
			String pass = "orcl11g";
			Connection con = DriverManager.getConnection(url, user, pass);
			System.out.println("Connection success");
			con.setAutoCommit(false);
			// Statement stmt = con.createStatement();

			String cmd = "insert into emp_tbl(empid,empname,empsalary) values(empid_sequence.nextval,?,?)";
			PreparedStatement pstmt = con.prepareStatement(cmd);

			pstmt.setString(1, "David");
			pstmt.setInt(2, 56000);
			int n = pstmt.executeUpdate();
			System.out.println("Insert success n = " + n);
			System.out.println("1.Commit\n2.Rollback");
			Scanner scr = new Scanner(System.in);
			int option = scr.nextInt();
			if (option == 1)
				con.commit();
			else
				con.rollback();
			con.close();
			// ResultSet rst = stmt.executeQuery(cmd);
			/*
			 * while (rst.next()) { int id = rst.getInt("empid"); String name =
			 * rst.getString("empname"); int sal = rst.getInt("empsalary");
			 * System.out.println(id + " " + name + " " + sal);
			 */
			// }
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
