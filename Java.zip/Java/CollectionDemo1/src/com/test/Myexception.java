package com.test;

public class Myexception extends Exception{
	
	public Myexception(String message)
	{
		System.out.println(message);
	}

}
