package com.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import java.util.Vector;

public class TestCollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list=new ArrayList();
		list.add("orange");
		list.add("apple");
		list.add("banana");
		list.add("grapes");
		Collections.sort(list);
	/*	list.add(0,"grapes");
		int n=list.size();
		list.clear();
		int n=list.size();
		System.out.println("size="+n);
		String obj=(String)list.get(2);
		System.out.println(obj);
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i));
		}*/
		System.out.println("****************");
		for(Object obj : list)
		{
			String str=(String) obj;
			System.out.println(str);
		}
		System.out.println("****************");
		Iterator iterator=list.iterator();
		while(iterator.hasNext())
		{
		Object obj=iterator.next();
		System.out.println(obj);
		}
		System.out.println("****************");
		list.forEach(p->System.out.println(p));
	}

}
