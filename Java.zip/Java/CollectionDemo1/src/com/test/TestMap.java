package com.test;

import java.util.Collection;
import java.util.HashMap;

public class TestMap {

	public static void main(String[] args) 
	{
		HashMap<Integer,Employee> map;
		map=new HashMap<Integer,Employee>();
		Employee e1=new Employee(2001,"John",9000);
		Employee e2=new Employee(1001,"Radha",8000);
		Employee e3=new Employee(3001,"Amar",6000);
		map.put(1001, e2);
		map.put(2001, e1);
		map.put(3001, e3);
		if (map.containsKey(2002))
		{
			Employee emp=map.get(2002);
			System.out.println(emp);
		}
		else
		{
			System.out.println("Employee not found!");
		}
		Collection<Employee> collection=map.values();
		collection.forEach(p->System.out.println(p));
	}

}
