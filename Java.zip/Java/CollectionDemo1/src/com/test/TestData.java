package com.test;

public class TestData {

	public static void main(String[] args) {
		
		Data<Integer> obj1=new Data<Integer>();
		Data<String> obj2=new Data<String>();
		Data<Employee> obj3=new Data<Employee>();		
		obj1.setData(100);
		obj2.setData("John");
		obj3.setData(new Employee());
		Employee employee=obj3.getData();
		System.out.println(employee);
		
		int i=obj1.getData();
		String str=obj2.getData();
		System.out.println(i);
		System.out.println(str);

	}

}
