package com.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestGeneric {

	public static List<String> getAllElements(List<String> list) {
		ArrayList<String> mylist = new ArrayList<String>();
		for (String str : list) {
			mylist.add(str);
		}
		return (mylist);
	}

	public static void printLastElement(List<String> list) {
		if (list != null && list.size() > 0) {
			int n = list.size() - 1;
			String str = list.get(n);
			System.out.println(str);
		} else
			try {
				throw new Myexception("List is empty or null");
			} catch (Myexception e) {
				e.printStackTrace();
			}
	}

	public static void main(String[] args) {

		/*ArrayList<String> list =new ArrayList<String>() ;
		list.add("one");
		list.add("two"); 
		list.add("three");*/
		
		List<String> list=Arrays.asList("one","two","three");
		
		printLastElement(list);
		
		List<String> nlist=getAllElements(list);
		for(String str:nlist)
		{
			System.out.println(str);
		}

	}

}
