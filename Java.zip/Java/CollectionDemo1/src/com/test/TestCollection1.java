package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class TestCollection1 {

	public static void main(String[] args) {
		Set<Employee> list=new TreeSet<Employee>(new EmployeeComparator());
	//	List list=new ArrayList();
		Employee e1=new Employee(2001,"John",9000);
		Employee e2=new Employee(1001,"Radha",8000);
		Employee e3=new Employee(3001,"Amar",6000);
		
		list.add(e1);
		list.add(e2);
		list.add(e3);
		//Collections.sort(list,new EmployeeComparator());
		
		for(Object obj : list)
		{
			Employee emp=(Employee) obj;
			System.out.println(emp.getEmployeeName());
		}
		
		list.forEach(p->System.out.println(p));

	}
}
