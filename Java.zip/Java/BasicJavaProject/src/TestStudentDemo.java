
public class TestStudentDemo {

	public static void main(String[] args) 
	{
		Student s1=new Student();
		s1.setRollNo(112081);
		s1.setStuName("Priyanka");
		s1.setMarks(80);
		
		Student s2=new Student();
		s2.setRollNo(555);
		s2.setStuName("Mauli");
		s2.setMarks(90);
	
		System.out.println("Roll No: "+s1.getRollNo()+
				" Student Name: "+s1.getStuName()+
				" You got: "+s1.getMarks());
		
		System.out.println("Roll No: "+s2.getRollNo()+
				" Student Name: "+s2.getStuName()+
				" You got: "+s2.getMarks());
	
	}

}
