
public class TestArrayDemo {

	public static void main(String[] args) 
	{
		int markArr[]=new int[4];
		markArr[0]=90;
		markArr[1]=10;
		markArr[2]=45;
		markArr[3]=78;	
	
	
	for(int i=0;i<markArr.length;i++)
	{
		System.out.println("markArr["+i+"]:"+markArr[i]);
	}
	System.out.println("***************All cities**************");
	}

}
