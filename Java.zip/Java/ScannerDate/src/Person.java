
public class Person 
{
	private String panNo;
	private String perName;
	private float personSal;
	Date personDOB;
	{
		panNo="unknown";
		perName="unknown";
		personSal=0.0F;
		personDOB=new Date();
	}
	public Person(String panNo,String perName,float personSal,Date personDOB)
	{
		this.panNo=panNo;
		this.perName=perName;
		this.personSal=personSal;
		this.personDOB=personDOB;
	}
	public String dispPersonInfo()
	{
		return "Person [panNo=" + panNo + ", perName=" + perName
				+ ", personSal=" + personSal + ", personDOB=" +personDOB.dispDate()
				+ "]";
	}
}
