import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class TestDateDemo33 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a date:\nYear= ");
		int year=sc.nextInt();
		System.out.println("\nMonth= ");
		int month=sc.nextInt();
		System.out.println("\nDay= ");
		int day=sc.nextInt();
		LocalDate date=LocalDate.of(year, month, day);
		LocalDate today=LocalDate.now();
		Period per=Period.between(date, today);
		System.out.println("Duration: "+per.getDays()+" Days "+per.getMonths()+
				" Months "+per.getYears()+" Years ");
	}

}
