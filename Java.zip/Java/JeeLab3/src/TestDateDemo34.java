import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class TestDateDemo34 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st date(dd-Mon-yyyy): ");
		String date1=sc.next();
		System.out.println("Enter 2st date(dd-Mon-yyyy): ");
		String date2=sc.next();
		
		DateTimeFormatter myFormater=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate dt1=LocalDate.parse(date1,myFormater);
		LocalDate dt2=LocalDate.parse(date2,myFormater);
		
		Period duration=Period.between(dt1, dt2);
		
		System.out.println("Duration: "+duration.getDays()+" days "+duration.getMonths()+
				" months "+duration.getYears()+" years ");

	}

}
