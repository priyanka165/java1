import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class TestDateDemo35 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter product purchase date(dd-Mon-yyyy): ");
		String date=sc.next();
		System.out.println("Enter the warranty period(in Months and Years): ");
		int months=sc.nextInt();
		int years=sc.nextInt();
		
		months=months+years*12;
		
		DateTimeFormatter myFormater=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate dt=LocalDate.parse(date,myFormater);
		
		System.out.println("Your warrantee expires on: "+
		(dt.plusMonths(months)).format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")));
	}
}
