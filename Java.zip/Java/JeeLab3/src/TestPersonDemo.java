import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class TestPersonDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);	
		System.out.println("Enter First Name ");
		String fn =sc.next();
		System.out.println("Enter Last Name ");
		String ln =sc.next();
		String fullname = getFullName(fn,ln);
		System.out.println("Enter gender(1 for male/2 for female) ");
		int gen = sc.nextInt();
		char gen1;
		if(gen==1)
		{
			gen1='M';
		}
		else if(gen==2)
		{
			gen1='F';
		}
		else
		{
			gen1='O';
		}
		System.out.println("Enter DOB(dd-MMM-yyyy) ");
		String dob =sc.next();
		Person perr=new Person(fn,ln,gen1,dob);
		Period per=calculateAge(dob);
		System.out.println(perr);
		System.out.println("Full Name is: "+fullname+"\nAge is: "+per.getYears()+
				" years "+per.getMonths()+" months "+per.getDays()+" days");
	}
	
	public static Period calculateAge(String dob)
	{
		DateTimeFormatter myFormater=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate date=LocalDate.parse(dob,myFormater);
		LocalDate today=LocalDate.now();
		Period per=Period.between(date, today);
		return per;
	}
	
	public static String getFullName(String fn,String ln)
	{
		fn+=" ";
		fn=fn.concat(ln);	
		return fn;
	}

}
