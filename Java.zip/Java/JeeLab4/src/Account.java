
public class Account {

	private long accNum;
	private double balance;
	private Person accHolder;
}
