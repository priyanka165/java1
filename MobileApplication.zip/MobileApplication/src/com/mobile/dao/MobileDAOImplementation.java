package com.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;
import com.mobile.util.DBConnection;

public class MobileDAOImplementation implements MobileDAO {

	
	public int generateMobileID() {
		int id = 0;
		Connection con = null;
		String qry = "select PurchaseId_Sequence.nextval from dual";
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id = rst.getInt(1);
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}

	
	@Override
	public int insertMobileDetails(MobileBean bean) throws MobileException {
		Connection con = null;
		String command = "insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values(?,?,?,?,SYSDATE,?);";
		int id = 0;
		PreparedStatement pstmt;
		try {
			con = DBConnection.getConnection();
			id = generateMobileID();
			pstmt = con.prepareStatement(command);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getCustName());
			pstmt.setString(3, bean.getMailId());
			pstmt.setLong(4, bean.getPhoneNo());
			pstmt.setInt(5, bean.getMobileId());
			pstmt.executeUpdate();
	        con.close();
		} catch (SQLException e) {
			throw new MobileException("Unable to insert");
		}
		return id;
	
	}
}

