package com.mobile.dao;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;

public interface MobileDAO {

	int insertMobileDetails(MobileBean bean) throws MobileException;
}
