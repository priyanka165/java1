package com.mobile.pl;

import java.util.Scanner;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;
import com.mobile.service.MobileService;
import com.mobile.service.MobileServiceImplementation;

public class MobileApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MobileBean bean = new MobileBean();
		MobileService service = new MobileServiceImplementation();
		System.out.println("Selection the desired operation:\n"
				+ "1.Insert the customer and purchase details into database\n"
				+ "2.View details of all mobiles available in the shop.\n"
				+ "3.Delete a mobile details based on mobile id.\n"
				+ "4.Search mobiles based on price range.");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("Enter Customer Name:");
			String custName=sc.next();
			System.out.println("Enter Mail ID:");
			String mailId=sc.next();
			System.out.println("Enter Phone Number:");
			long phoneNo=sc.nextLong();
			System.out.println("Enter Mobile ID:");
			int mobileID=sc.nextInt();
			
			bean.setCustName(custName);
			bean.setMailId(mailId);
			bean.setPhoneNo(phoneNo);
			bean.setMobileId(mobileID);
			
			try {
				int id = service.insertMobileDetails(bean);
				System.out.println("Mobile details inserted successfully");
				System.out.println("Mobile ID is: " + id);
			} catch (MobileException e) {
				e.printStackTrace();
			}
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		default:
			System.out.println("Give valid operation");
			break;
		}

	}

}
