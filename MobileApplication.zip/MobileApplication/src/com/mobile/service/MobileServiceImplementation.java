package com.mobile.service;

import com.mobile.bean.MobileBean;
import com.mobile.dao.MobileDAO;
import com.mobile.dao.MobileDAOImplementation;
import com.mobile.exception.MobileException;

public class MobileServiceImplementation implements MobileService {

	MobileDAO mobiledao = new MobileDAOImplementation();
	
	@Override
	public int insertMobileDetails(MobileBean bean) throws MobileException {
			int id = mobiledao.insertMobileDetails(bean);
			return id;
		}
}
