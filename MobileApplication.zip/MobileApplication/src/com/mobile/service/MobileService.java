package com.mobile.service;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;

public interface MobileService {

	int insertMobileDetails(MobileBean bean) throws MobileException;

}
